# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

# Copyright (c) 2018 Intellego-BI.com (https://intellego-bi.com).
